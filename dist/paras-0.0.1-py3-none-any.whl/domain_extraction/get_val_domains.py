#!/usr/bin/env python

from sys import argv

def read_fasta(fasta_dir):
    with open(fasta_dir, 'r') as fasta_file:
        fasta_dict = {}
        sequence = []
        for line in fasta_file:
            line = line.strip()

            if line.startswith(">"):
                if sequence:
                    fasta_dict[ID] = ''.join(sequence)

                    ID = line[1:]
                    sequence = []
                else:
                    ID = line[1:]

            else:
                sequence.append(line)

        fasta_dict[ID] = ''.join(sequence)
        fasta_file.close()
    return fasta_dict

def parse_spec(fasta_id):
    spec = fasta_id.split('_')[1]
    return spec

def get_val_domains(fasta_dir, out_dir):


    fasta = read_fasta(fasta_dir)

    with open(out_dir, 'w') as out_file:
        for id, seq in fasta.items():
            if parse_spec(id) == 'Val':
                out_file.write(f'>{id.split("_")[0]}\n{seq}\n')


if __name__ == "__main__":
    get_val_domains(argv[1], argv[2])

