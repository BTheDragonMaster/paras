PARAS: Predictive Algorithm for Resolving A-domain specificity
