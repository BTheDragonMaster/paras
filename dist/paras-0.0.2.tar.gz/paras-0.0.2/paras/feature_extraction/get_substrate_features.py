from pikachu.general import read_smiles
from pikachu.fingerprinting.ecfp_4 import build_ecfp_bitvector

